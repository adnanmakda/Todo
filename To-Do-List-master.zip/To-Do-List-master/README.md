# To-Do-List

A simple to-do list webapp based on Javascript. It uses MDL library for front end components.<br>
It has three tabs - Add Item, To-Do Tasks, Completed.<br>
Add Item - Task can be added to the list of To-Do Tasks.<br>
To-Do Tasks - Lists the current list of to-do of the user, has option to mark as completed and move to completed tab or delete it from the list altogether.<br>
Completed - Lists the completed tasks of the user and an option to delete it from the list.<br>
